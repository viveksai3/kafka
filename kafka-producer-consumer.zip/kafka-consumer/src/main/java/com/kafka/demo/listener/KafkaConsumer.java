package com.kafka.demo.listener;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.kafka.demo.model.User;

@Service
public class KafkaConsumer {
	
	@KafkaListener(topics="Kafka_Ex",groupId ="group_id")
	public void consume(String message)
	{
		System.out.println("consumed message"+message);
	}
	
	@KafkaListener(topics="json", groupId="group_json",containerFactory = "userKafkaListenerFactory")
	public void consumeJson(User user)
	{
		System.out.println("consumed json message: " +user);
	}

}
