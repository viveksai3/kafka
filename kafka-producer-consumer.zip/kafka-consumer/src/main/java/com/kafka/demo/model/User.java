package com.kafka.demo.model;

public class User {
	private String name;
	private int id;
	private String designation;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public User(String name, int id, String designation) {
		super();
		this.name = name;
		this.id = id;
		this.designation = designation;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", id=" + id + ", designation=" + designation + "]";
	}
	

}
